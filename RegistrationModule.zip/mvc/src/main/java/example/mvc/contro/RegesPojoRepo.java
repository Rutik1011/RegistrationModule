package example.mvc.contro;

import org.springframework.data.jpa.repository.JpaRepository;
                                        // jpaRepository is present in JPA dependancy
public interface RegesPojoRepo extends JpaRepository<RegesPojo,Long> {

}
