package example.mvc.contro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Pra1 {
	@Autowired
	RegesPojoRepo regRepo;

	@GetMapping("/regist")  // Started from here....
	public String reg()
	{
		return"regesration";
	}

	@GetMapping("/reg")                                  // it is for multiple values present in .jsp file
	public String reg(@ModelAttribute RegesPojo reg)     // @modelAttribue is used when plaing with pojoclass
	{
		System.out.println(reg);
		return "regesration";
	}

	//main            // it API same like"/regist"
	@GetMapping("/")  //The GET method appends data to the URL as query parameters (e.g., ?name=value&other=value). This makes the data visible in the browser's address bar
	public String dispPage(Model mo)
	{
		mo.addAttribute("RegesPojo",regRepo.findAll());
		return "regesration"; //regesration.jsp  // 'regesration' is the name of JSP file that we are cretad in 'src' file.
		// we dont need to give '.jsp'extention to 'regesration' beacuse we added prefix and sufix in application.properties
	}

	@PostMapping("/add")  //The POST method sends data in the request body, which is not visible in the URL.
	public String add(@ModelAttribute RegesPojo po)
	{
		regRepo.save(po);
		return "regesration";
	}


	@GetMapping("/disp")            // it is for single value present in .jsp file
	//@requestParam use in mvc when you wan to give value from user
	public String disp(@RequestParam(value = "fnm", required = false) String fnm)
	{
		System.out.println(fnm);
		return "new";
	}
}
